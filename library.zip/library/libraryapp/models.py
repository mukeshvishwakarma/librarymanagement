from django.db import models
from django.db.models import CharField, Value as V
from django.db.models.functions import Concat
from django.contrib.auth.models import AbstractUser


class UserModel(models.Model):
    location = models.CharField(max_length=80)
    
    class Meta:
        managed = False
        db_table='usermodel'


class booktbl(models.Model):
    
    id = models.IntegerField(primary_key=True),
    book_id = models.CharField(max_length=50)
    bookname = models.CharField(max_length=20)
    uther = models.CharField(max_length=20)
    datetime = models.DateField(max_length=20)
    
    class Meta:
        managed=False
        db_table='librarybook'

class CustomUser(models.Model):
    id=models.IntegerField(primary_key=True)
   
    email=models.CharField(unique=True,max_length=255)
    username=models.CharField(unique=True,max_length=255)
    password=models.CharField(max_length=255)
  

    class Meta:
        managed = False  
        db_table = "users"
