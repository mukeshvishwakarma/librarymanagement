from django import forms  
from django.core.exceptions import ValidationError
from django.db.models import fields
from django.forms import widgets
from libraryapp.models import *

class bookForm(forms.ModelForm):  
    class Meta:  
        model = booktbl  
        fields = '__all__'
        widgets = { 'book_id': forms.NumberInput(attrs={ 'class': 'form-control' }), 
            'bookname': forms.TextInput(attrs={ 'class': 'form-control' }),
            'uther': forms.TextInput(attrs={ 'class': 'form-control' }),
            'datetime': forms.DateInput(attrs={ 'class': 'form-control' }),
      }