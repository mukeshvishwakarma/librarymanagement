from sqlite3 import Cursor
from django.shortcuts import render, redirect 
from django.contrib import messages
from django.db import connection
from libraryapp.forms import *  
from libraryapp.models import *  
from django.contrib.auth.models import User,Group
from django.contrib.auth import authenticate,login,logout
from django.contrib import messages


# Create your views here. 



def UserReg(request):
    
    if request.method == 'POST':
        username =request.POST['username']
        email =request.POST['email']
        password1 =request.POST['password1']
        password2 =request.POST['password2']
        
    
        if password1==password2:
            if CustomUser.objects.filter(username=username).exists():
                messages.error(request,'Username already taken...')
                return redirect('UserReg')
            elif CustomUser.objects.filter(email=email).exists():
                messages.error(request,'Email already exist....')
                return redirect('UserReg')
            else:
                # user = CustomUser.objects.create_user(username = username, email= email, password1=password1)
                # user.save()
                CustomUser(username = username, email = email, password = password1).save()
                # messages.info(request,'User Created')
                # user_group = Group.objects.get(name='customer')

                # user.groups.add(user_group)
                return redirect('book')#customerLogin
                # return HttpResponse("user create")
        else:
            messages.error(request,' Password not matching...')
            return redirect('UserReg')
        # return redirect('/')
    else:
        pass
    return render (request,'user_register.html')

def user_login(request):

    if request.method == 'POST':
        logusername =request.POST['logusername']
        logpassword =request.POST['logpassword']

        myuser = authenticate(username=logusername, password=logpassword)

        if myuser is not None:
            login(request, myuser)
            return render(request, 'show.html')
        else:
            messages.error(request, 'Invalid Username OR password')
            return redirect('user_login')
    return render(request,'user_login.html')


 
def signout(request): 
    logout(request)
    messages.success(request, "Logged Out Successfully!")
    return redirect('user_login')


def bookaddnew(request):
    cursor = connection.cursor()
    cursor.execute("select max(id) from librarybook order by id desc limit 1")
    r = cursor.fetchone()
    if r[0] == '' or r[0] == None:
        r = '1'
    else:
        r =str(int(r[0])+1)
    print(r[0])

    if request.method == "POST":  
    
            bi=request.POST.get('book_id')
            lb=request.POST.get('bookname')
            au=request.POST.get('uther')
            dt=request.POST.get('datetime')
           
          
            
            if booktbl.objects.filter(book_id=bi).exists():
                bi=booktbl.objects.order_by('book_id').last().book_id + 1
            booktbl(book_id=bi,bookname=lb,uther=au,datetime=dt).save()
            return redirect('/book') 

    else:
        form = bookForm()
    
    return render(request,'book/index.html',{'form':form,'ren':r})  

def bookindex(request):  
    ren = booktbl.objects.all()
    return render(request,"book/show.html",{'ren':ren})  

def bookedit(request, id):  
    ren = booktbl.objects.get(id=id)  
    return render(request,'book/edit.html', {'ren':ren})  

def bookupdate(request, id): 
    ren = booktbl.objects.get(id=id)  
    form = bookForm(request.POST or None, instance = ren)  
    if form.is_valid():  
        form.save()  
        return redirect("book")
    else:
        form = bookForm(instance = ren)
        # messages.error(request,'Machine Master Already Exists')  
    return render(request, 'book/edit.html', {'ren': ren,'form': form})  

def bookdestroy(request, id):  
    ren = booktbl.objects.get(id=id)  
    ren.delete()  
    return redirect("book") 